%    function [y] = fft_model(x,nps,inverse)             
%                                                                                             
%   Calculates the complex fixed-point FFT/IFFT for variable transform
%   sizes (stored in vector nps) of the complex input vector x.
%
%   Uses the fixed point model of the Variable Streaming architecture.
%                                                                                             
%   Inputs:   x          : Input complex vector. x will be split into blocks
%                          of various sizes as specified by nps. The size of this
%                          vector must greater than or equal to the sum of the
%                          values in nps.
%                          appended to the input sequence appropriately.                      
%             nps        : A vector of transform Lengths to be applied on a block-by-block basis.                
%             inverse    : A vector specifying the FFT direction on a block-by-block basis.   
%                          0 => FFT                                                           
%                          1 => IFFT
%                                                                                             
%   Outputs   y          : The transform-domain complex vector output                         
%                                                     
%                                                                                             
%   2001-2007 Altera Corporation, All Rights Reserved
%                                                                                                  
%   Automatically Generated: FFT MegaCore Function 7.1 Build 156 May, 2007                                                                                                   
%
function [y] = fft512_model(x,nps,inverse)         
addpath('c:/altera/71/ip/fft/lib//ip_toolbench//../');
% Parameterization Space    
N=512;
DATA_PREC=16;
TWIDDLE_PREC=16;
% Input is in bit-reversed order
INPUT_ORDER=0;  
% Output is in natural order                                                           
OUTPUT_ORDER=1;                                                         
y=[];           
i=1;
%for each block in the vector N, perform the transform
for i=1:length(nps)                                                                      
    rin = real(x(1:nps(i)));                                                          
    iin = imag(x(1:nps(i)));                                                                       
    [roc,ioc] = SVSfftmodel(rin,iin,DATA_PREC,TWIDDLE_PREC,N,nps(i),inverse(i), INPUT_ORDER, OUTPUT_ORDER);      
    y = [y, roc+j*ioc]   ;
    %remove block from input vector
    x=x(nps(i)+1:end);  
end                                                                                           

