
N = 1536;
r = 37;


r = 4;
x1 = 1024*[zeros(1,r) 1 zeros(1,1535-r)];
x2 = [1024*ones(1,N-r) zeros(1,r)];
x3 = round(32*cos(2*pi*(0:N-1)/N));
x = [x1 x2 x3];

fidr = fopen('..\source\real_input.txt','w');  
fidi = fopen('..\source\imag_input.txt','w'); 
fprintf(fidr,'%d\n',real(x));                                                 
fprintf(fidi,'%d\n',imag(x));
fclose(fidr);                                                                 
fclose(fidi);
                 
