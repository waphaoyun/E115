function xBitRev = BitReverse(x, N);

%N = 16;
tmp = 0;
bitwidth = log2(N);
  
    for i = 0:N-1
        tmp = i;
        for j = 0:bitwidth-1
            bit(i+1, j+1) = mod(tmp,2);
            tmp = floor(tmp/2);
        end
    end

address = zeros(1, N);

    for i = 0:N-1
        tmp = 0;
        for j = 0:bitwidth-1
            tmp = bit(i+1, j+1)*2^(bitwidth-1-j) + tmp;
        end
        address(i+1) = tmp;
        xBitRev(i+1) = x(address(i+1)+1);
    end    

    
%    
%    aBitRev = zeros(1,N);
%    rev = 0;
%    halfPoints = N/2;
%    for i = 1:N
%        aBitRev(i) = rev;
%        mask = halfPoints;
%        % add 1 backwards
%        while (rev >= mask)
%        %    rev -= mask; // turn off this bit
%            rev = rev - mask;
%        %    mask >>= 1;
%            mask = floor(mask/2);
%        end
%        %rev += mask;
%        rev = rev + mask;
%    end
%    aBitRev(N) = a(N);
