% inverse: 0:fft; 1:ifft
% N: number of points
% bit_width: 
% tf_branch: 1: one period per N points
%            2: two period per N points

function [twiddle] = gen_twiddle_factor(inverse, N, bit_width, tf_branch);


coshex_val = zeros(N,1);
sinhex_val = zeros(N,1);
coshex = zeros(N,1);
sinhex = zeros(N,1);
digit = ceil(bit_width/4);
for i=1:N
    if(inverse)
        coshex_val(i) = cos((tf_branch*2*pi/N)*(i-1));
        sinhex_val(i) = sin((tf_branch*2*pi/N)*(i-1));
    else
        coshex_val(i) = cos((tf_branch*2*pi/N)*(i-1));
        sinhex_val(i) = -sin((tf_branch*2*pi/N)*(i-1));
    end    
end

%scaled version of the twiddle factors based on bit width

%scaling_factor = 2^(bit_width -1 ) -1
scaling_factor = 2^(bit_width -1 );

for i=1:N
    coshex(i) = round(coshex_val(i) * scaling_factor);
    sinhex(i) = round(sinhex_val(i) * scaling_factor);

end

for i=1:N
    if(coshex(i) == 2^(bit_width-1))
        coshex(i) = 2^(bit_width-1)-1;
    end
    if(coshex(i) == -2^(bit_width-1))
        coshex(i) = -(2^(bit_width-1)-1);       
    end
    if(sinhex(i) == 2^(bit_width-1))
        sinhex(i) = 2^(bit_width-1)-1;
    end
    if(sinhex(i) == -2^(bit_width-1))
        sinhex(i) = -(2^(bit_width-1)-1);       
    end
end

twiddle = coshex + j*sinhex;

k=1;
for i=1:N/8
    for t=1:8
        if (k<=N)
        coshex_c(i,t)=coshex(k);
        sinhex_c(i,t)=sinhex(k);
        k=k+1;   
        end
    end
end